﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MigrationAnalyzer.Models;

namespace MigrationAnalyzer.Analyzer
{
    public static class ProjectReportGenerator
    {
        public static string GenerateMarkdown(ProjectInfo info)
        {
            var sb = new StringBuilder();
            sb.AppendLine("# Migration Report");
            sb.AppendLine();
            sb.AppendLine("## Project File");
            sb.AppendLine($"- {info.CsProjPath}");
            sb.AppendLine();

            foreach (var file in info.Files)
            {
                sb.AppendLine($"### {file.FileType}: `{file.FilePath}`");
                sb.AppendLine(file.AnalysisResult);
                sb.AppendLine();
            }

            return sb.ToString();
        }
    }
}
