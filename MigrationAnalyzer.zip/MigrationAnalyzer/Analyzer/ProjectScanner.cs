﻿using Microsoft.VisualBasic.FileIO;
using MigrationAnalyzer.Models;
using OpenAI.Assistants;
using Polly;
using Polly.Retry;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MigrationAnalyzer.Analyzer
{
    public class ProjectScanner
    {
        private readonly GptFileAnalyzer _gptAnalyzer;

        public ProjectScanner(GptFileAnalyzer gptAnalyzer)
        {
            _gptAnalyzer = gptAnalyzer;
        }

        //public async Task<ProjectInfo> ScanProjectAsync(string directory)
        //{
        //    var projectInfo = new ProjectInfo();
        //    projectInfo.CsProjPath = Directory.GetFiles(directory, "*.csproj", System.IO.SearchOption.AllDirectories)
        //                                      .FirstOrDefault() ?? "";

        //    var allFiles = Directory.GetFiles(directory, "*.*", System.IO.SearchOption.AllDirectories)
        //        .Where(f => f.EndsWith(".cs") || f.EndsWith(".cshtml") || f.EndsWith(".config"))
        //        .ToList();

        //    foreach (var filePath in allFiles)
        //    {
        //        var ext = Path.GetExtension(filePath).ToLowerInvariant();
        //        string fileType = "Unknown";
        //        FileType fileTypeEnum = FileType.Unknown;

        //        if (filePath.EndsWith("Controller.cs", StringComparison.OrdinalIgnoreCase))
        //        {
        //            fileType = "Controller File";
        //            fileTypeEnum = FileType.ControllerFile;
        //        }


        //        else if (filePath.Contains($"{Path.DirectorySeparatorChar}Models{Path.DirectorySeparatorChar}", StringComparison.OrdinalIgnoreCase))
        //        {
        //            fileType = "Model File";
        //            fileTypeEnum = FileType.ModelFile;
        //        }

        //        else if (filePath.Contains($"{Path.DirectorySeparatorChar}Views{Path.DirectorySeparatorChar}", StringComparison.OrdinalIgnoreCase))
        //        {
        //            if (ext == ".cshtml" || ext == ".ascx")
        //            {
        //                fileType = "Partial View";
        //                fileTypeEnum = FileType.PartialView;
        //            }
        //            else if (ext == ".aspx")
        //            {
        //                fileType = "ASPX Page (View)";
        //                fileTypeEnum = FileType.AspxPage;
        //            }
        //        }

        //        else if (ext == ".aspx")
        //        {
        //            fileType = "ASPX Page (View)";
        //            fileTypeEnum = FileType.AspxPage;
        //        }

        //        else if (ext == ".ascx" || ext == ".cshtml")
        //        {
        //            fileType = "Partial View";
        //            fileTypeEnum = FileType.PartialView;
        //        }

        //        else if (filePath.EndsWith("web.config", StringComparison.OrdinalIgnoreCase) ||
        //                 filePath.EndsWith("app.config", StringComparison.OrdinalIgnoreCase))
        //        {
        //            fileType = "Web.config/App.config";
        //            fileTypeEnum = FileType.WebOrAppConfig;
        //        }

        //        else if (ext == ".js")
        //        {
        //            fileType = "JavaScript/Client Code";
        //            fileTypeEnum = FileType.JavaScriptClientCode;
        //        }

        //        else if (ext == ".css")
        //        {
        //            fileType = "CSS/Static Assets";
        //            fileTypeEnum = FileType.CssStaticAsset;
        //        }

        //        else if (ext == ".cs")
        //        {
        //            var content = File.ReadAllText(filePath);
        //            if (content.Contains("DbContext") || content.Contains("Repository"))
        //            {
        //                fileType = "Data Access/File";
        //                fileTypeEnum = FileType.DataAccessFile;
        //            }
        //            else
        //            {
        //                fileType = "Class File";
        //                fileTypeEnum = FileType.ClassFile;
        //            }
        //        }

        //        string fileContent = File.ReadAllText(filePath);
        //        string originalVersion = "4.5.2";
        //        // GPT-based analysis
        //        string gptAnalysis = await _gptAnalyzer.AnalyzeFileAsync(filePath, fileType, fileTypeEnum, fileContent, originalVersion);

        //        projectInfo.Files.Add(new AnalyzedFileInfo
        //        {
        //            FilePath = filePath,
        //            FileType = fileType,
        //            AnalysisResult = gptAnalysis
        //        });
        //    }
        //    return projectInfo;
        //}



        public async Task<ProjectInfo> ScanProjectAsync(string directory)
        {
            var projectInfo = new ProjectInfo();
            projectInfo.CsProjPath = Directory.GetFiles(directory, "*.csproj", System.IO.SearchOption.AllDirectories)
                                              .FirstOrDefault() ?? "";

            var filePattern = new Regex(
    @"(?i)(?:
        \.cs$|
        \.cshtml$|
        \.config$|
        \.aspx$|
        \.ascx$|
        \.js$|
        \.css$|
        \.aspx\.cs$|
        \.aspx\.designer\.cs$|
        site\.master(\.designer)?\.cs$|
        site\.mobile\.master(\.designer)?\.cs$|
        global\.asax(\.cs|\.designer\.cs)?$
    )", RegexOptions.IgnorePatternWhitespace | RegexOptions.IgnoreCase | RegexOptions.Compiled);

            var allFiles = Directory.GetFiles(directory, "*.*", System.IO.SearchOption.AllDirectories)
                .Where(f => filePattern.IsMatch(Path.GetFileName(f)))
                .ToList();


            var analyzedFiles = new ConcurrentBag<AnalyzedFileInfo>();
            var retryPolicy = Policy
                .Handle<Exception>()
                .WaitAndRetryAsync(3, attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt)));

            await Parallel.ForEachAsync(allFiles, new ParallelOptions { MaxDegreeOfParallelism = 6 }, async (filePath, token) =>
            {
                try
                {
                    //var ext = Path.GetExtension(filePath).ToLowerInvariant();
                    //string fileType = "Unknown";
                    //FileType fileTypeEnum = FileType.Unknown;

                    //if (filePath.EndsWith("Controller.cs", StringComparison.OrdinalIgnoreCase))
                    //{
                    //    fileType = "Controller File";
                    //    fileTypeEnum = FileType.ControllerFile;
                    //}
                    //else if (filePath.Contains($"{Path.DirectorySeparatorChar}Models{Path.DirectorySeparatorChar}", StringComparison.OrdinalIgnoreCase))
                    //{
                    //    fileType = "Model File";
                    //    fileTypeEnum = FileType.ModelFile;
                    //}
                    //else if (filePath.Contains($"{Path.DirectorySeparatorChar}Views{Path.DirectorySeparatorChar}", StringComparison.OrdinalIgnoreCase))
                    //{
                    //    if (ext is ".cshtml" or ".ascx")
                    //    {
                    //        fileType = "Partial View";
                    //        fileTypeEnum = FileType.PartialView;
                    //    }
                    //    else if (ext == ".aspx")
                    //    {
                    //        fileType = "ASPX Page (View)";
                    //        fileTypeEnum = FileType.AspxPage;
                    //    }
                    //}
                    //else if (ext == ".aspx")
                    //{
                    //    fileType = "ASPX Page (View)";
                    //    fileTypeEnum = FileType.AspxPage;
                    //}
                    //else if (ext == ".ascx" || ext == ".cshtml")
                    //{
                    //    fileType = "Partial View";
                    //    fileTypeEnum = FileType.PartialView;
                    //}
                    //else if (filePath.EndsWith("web.config", StringComparison.OrdinalIgnoreCase) ||
                    //         filePath.EndsWith("app.config", StringComparison.OrdinalIgnoreCase))
                    //{
                    //    fileType = "Web.config/App.config";
                    //    fileTypeEnum = FileType.WebOrAppConfig;
                    //}
                    //else if (ext == ".js")
                    //{
                    //    fileType = "JavaScript/Client Code";
                    //    fileTypeEnum = FileType.JavaScriptClientCode;
                    //}
                    //else if (ext == ".css")
                    //{
                    //    fileType = "CSS/Static Assets";
                    //    fileTypeEnum = FileType.CssStaticAsset;
                    //}
                    //else if (ext == ".cs")
                    //{
                    //    string content = await File.ReadAllTextAsync(filePath, token);
                    //    if (content.Contains("DbContext") || content.Contains("Repository"))
                    //    {
                    //        fileType = "Data Access/File";
                    //        fileTypeEnum = FileType.DataAccessFile;
                    //    }
                    //    else
                    //    {
                    //        fileType = "Class File";
                    //        fileTypeEnum = FileType.ClassFile;
                    //    }
                    //}

                    var ext = Path.GetExtension(filePath).ToLowerInvariant();
                    var fileName = Path.GetFileName(filePath).ToLowerInvariant();
                    string fileType = "Unknown";
                    FileType fileTypeEnum = FileType.Unknown;

                    if (fileName.EndsWith("controller.cs"))
                    {
                        fileType = "Controller File";
                        fileTypeEnum = FileType.ControllerFile;
                    }
                    else if (filePath.Contains($"{Path.DirectorySeparatorChar}Models{Path.DirectorySeparatorChar}", StringComparison.OrdinalIgnoreCase))
                    {
                        fileType = "Model File";
                        fileTypeEnum = FileType.ModelFile;
                    }
                    else if (filePath.Contains($"{Path.DirectorySeparatorChar}Views{Path.DirectorySeparatorChar}", StringComparison.OrdinalIgnoreCase))
                    {
                        if (ext is ".cshtml" or ".ascx")
                        {
                            fileType = "Partial View";
                            fileTypeEnum = FileType.PartialView;
                        }
                        else if (ext == ".aspx")
                        {
                            fileType = "ASPX Page (View)";
                            fileTypeEnum = FileType.AspxPage;
                        }
                    }
                    else if (fileName.EndsWith(".aspx.cs") || fileName.EndsWith(".aspx.designer.cs"))
                    {
                        fileType = "ASPX Code-Behind File";
                        fileTypeEnum = FileType.CodeBehindFile;
                    }
                    else if (fileName.Contains("site.master") && fileName.EndsWith(".cs"))
                    {
                        fileType = "Master Page Code File";
                        fileTypeEnum = FileType.MasterPageFile;
                    }
                    else if (ext == ".aspx")
                    {
                        fileType = "ASPX Page (View)";
                        fileTypeEnum = FileType.AspxPage;
                    }
                    else if (ext == ".ascx" || ext == ".cshtml")
                    {
                        fileType = "Partial View";
                        fileTypeEnum = FileType.PartialView;
                    }
                    else if (fileName.EndsWith("web.config") || fileName.EndsWith("app.config"))
                    {
                        fileType = "Web.config/App.config";
                        fileTypeEnum = FileType.WebOrAppConfig;
                    }
                    else if (ext == ".js")
                    {
                        fileType = "JavaScript/Client Code";
                        fileTypeEnum = FileType.JavaScriptClientCode;
                    }
                    else if (ext == ".css")
                    {
                        fileType = "CSS/Static Assets";
                        fileTypeEnum = FileType.CssStaticAsset;
                    }
                    else if (ext == ".cs")
                    {
                        var content = File.ReadAllText(filePath);
                        if (content.Contains("DbContext") || content.Contains("Repository"))
                        {
                            fileType = "Data Access/File";
                            fileTypeEnum = FileType.DataAccessFile;
                        }
                        else
                        {
                            fileType = "Class File";
                            fileTypeEnum = FileType.ClassFile;
                        }
                    }
                    else if (fileName == "global.asax" || fileName == "global.asax.cs" || fileName == "global.asax.designer.cs")
                    {
                        fileType = "Global.asax File";
                        fileTypeEnum = FileType.GlobalAsaxFile;
                    }

                    string fileContent = await File.ReadAllTextAsync(filePath, token);
                    string originalVersion = "4.5.2";

                    string gptAnalysis = await retryPolicy.ExecuteAsync(() =>
                        _gptAnalyzer.AnalyzeFileAsync(filePath, fileType, fileTypeEnum, fileContent, originalVersion));

                    analyzedFiles.Add(new AnalyzedFileInfo
                    {
                        FilePath = filePath,
                        FileType = fileType,
                        AnalysisResult = gptAnalysis
                    });
                    Console.WriteLine("Analysed File: {0}", fileName);
                    Console.WriteLine("Analysed File Count: {0}", analyzedFiles.Count);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[ERROR] {filePath}: {ex.Message}");
                }
            });

            projectInfo.Files = analyzedFiles.ToList();
            return projectInfo;
        }

    }
}