﻿using MigrationAnalyzer.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MigrationAnalyzer.Analyzer
{
    public static class Extentions
    {
        public static string GetDescription(this FileType fileType)
        {
            var field = fileType.GetType().GetField(fileType.ToString());
            var attr = (DescriptionAttribute)Attribute.GetCustomAttribute(field, typeof(DescriptionAttribute));
            return attr?.Description ?? fileType.ToString();
        }
    }
}
