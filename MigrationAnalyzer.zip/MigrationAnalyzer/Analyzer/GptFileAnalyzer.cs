﻿using Azure;
using Azure.AI.OpenAI;
using MigrationAnalyzer.Models;
using OpenAI.Chat;
using System;
using System.ClientModel.Primitives;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MigrationAnalyzer.Analyzer
{
    public class GptFileAnalyzer
    {
        private readonly AzureOpenAIClient _client;
        private readonly string _deploymentName;

        public GptFileAnalyzer(AzureOpenAIClient client, string deploymentName)
        {
            _client = client;
            _deploymentName = deploymentName;
        }

        public async Task<string> AnalyzeFileAsync(string filePath, string fileType, FileType fileTypeEnum, string fileContent, string originalVersion)
        {
            // You may want smarter prompt customization here!
            string prompt = $@"
You are an expert .NET migration assistant.
Analyze the following {fileType} file '{Path.GetFileName(filePath)}'.
Identify legacy patterns, migration risks, and recommendations to upgrade it to .NET 8 ({fileType}-specific issues, API changes, obsolete APIs, configuration/namespace requiring attention, and migration tips).
---
{fileContent}
---
Return your findings in clear bullet points.
";

            string promptController = $@"
You are an expert .NET migration assistant.
Analyze the following **controller** file '{Path.GetFileName(filePath)}'written for ASP.NET MVC (.NET Framework {originalVersion}). Identify legacy controller patterns, obsolete or deprecated APIs, lifecycle differences, security constructs, and recommend best practices to migrate it to .NET 8 (controllers, endpoint routing, API/controller inheritance, dependency injection, attribute routing, namespace changes, and asynchronous programming patterns). Provide migration risks, API changes, and code modernization tips specific to controller files.
---
{fileContent}
---
Return your findings in clear bullet points.
";

            string promptModel = $@"
You are an expert .NET migration assistant.
Analyze the following **model** file '{Path.GetFileName(filePath)}' developed for ASP.NET MVC ({originalVersion}). Detect legacy model patterns, data annotations, validation attributes, serialization approaches, nullable value handling, and Entity Framework usage. Recommend updates required for .NET 8 compatibility, such as changes in data annotations, nullable reference types, EF Core compatibility, and new C# features. Highlight potential migration dangers and modernization strategies.
---
{fileContent}
---
Return your findings in clear bullet points.
";

            string promptAspx = $@"
You are an expert .NET migration assistant.
Examine the following **ASPX view** file '{Path.GetFileName(filePath)}' created for ASP.NET MVC/Web Forms ({originalVersion}). Detail legacy syntaxes, code-behind logic, inline C#/VB code, deprecated controls, and incompatible lifecycle events. Provide explicit recommendations for upgrading to .NET 8 (Razor Pages, modern view engines, client-side rendering, partial views, and the removal/modernization of code-behind patterns). Note migration blockers and risks regarding UI and event model changes.
---
{fileContent}
---
Return your findings in clear bullet points.
";

            string promptConfig = $@"
You are an expert .NET migration assistant.
Review the following **configuration** file '{Path.GetFileName(filePath)}' (Web.config/App.config) used in ASP.NET MVC (.NET Framework {originalVersion}). Identify obsolete configuration sections, deprecated handlers/modules, authentication/authorization setups, and legacy settings needing changes or removal for .NET 8 migration. Recommend best practices for moving settings to modern appsettings.json, environment variables, and .NET 8-style middleware and options patterns, highlighting critical migration steps and pitfalls.
---
{fileContent}
---
Return your findings in clear bullet points.
";

            string promptScript = $@"
You are an expert .NET migration assistant.
Analyze the following **JavaScript/client-side** file '{Path.GetFileName(filePath)}' from an ASP.NET MVC project. Detect usage of legacy MVC-provided scripts, Ajax patterns, jQuery dependencies, anti-forgery integrations, and browser compatibility issues. Advise on best practices to modernize for .NET 8, including using SPA frameworks (React/Angular), secure API calls, and ES6+ syntax upgrades. Call out migration risks and potential integration challenges with modern .NET APIs.
---
{fileContent}
---
Return your findings in clear bullet points.
";

            string promptAssets = $@"
You are an expert .NET migration assistant.
Examine the following **CSS/static asset** file '{Path.GetFileName(filePath)}' in an ASP.NET MVC project. Check for legacy ASP.NET constructs, embedded resources, bundling/minification references, and compatibility with .NET 8’s static file handling. Suggest modernization tips, use of build tools (Webpack, Vite), and migration of static content to new folder structures as per .NET 8 conventions.Examine the following **CSS/static asset** file '{Path.GetFileName(filePath)}' in an ASP.NET MVC project. Check for legacy ASP.NET constructs, embedded resources, bundling/minification references, and compatibility with .NET 8’s static file handling. Suggest modernization tips, use of build tools (Webpack, Vite), and migration of static content to new folder structures as per .NET 8 conventions.
---
{fileContent}
---
Return your findings in clear bullet points.
";

            string promptpartialView = $@"
You are an expert .NET migration assistant.
Evaluate the following **partial view** file '{Path.GetFileName(filePath)}' ({originalVersion}), identifying old syntax, helper usage, model binding, and layout integration. Advise on converting to modern Razor partials (.cshtml), compatibility with .NET 8's view rendering, and refactoring patterns for separation of concerns and maintainability. List legacy features incompatible with .NET 8 and provide clear upgrade guidance.
---
{fileContent}
---
Return your findings in clear bullet points.
";

            string promptDataAccess = $@"
You are an expert .NET migration assistant.
Scrutinize the following **data access** file '{Path.GetFileName(filePath)}', used in ASP.NET MVC with EF or ADO.NET ({originalVersion}). Highlight patterns incompatible with EF Core or .NET 8 (e.g., EDMX models, ObjectContext, synchronous DB access, LINQ syntax). Recommend migration to EF Core, async methods, updated LINQ queries, and connection resiliency patterns, outlining key risks and refactoring advice.
---
{fileContent}
---
Return your findings in clear bullet points.
";

            string promptGlobalAsax = $@"
You are an expert .NET migration assistant.
Analyze the following Global.asax file '{Path.GetFileName(filePath)}' used in an ASP.NET MVC (.NET Framework {originalVersion}) project.
Identify legacy constructs like `Application_Start`, `Application_BeginRequest`, `HttpModules`, or `HttpHandlers`, and provide modern equivalents using .NET 8 middleware, `Program.cs`, or `Startup.cs`. Highlight obsolete patterns and advise migration strategies.
---
{fileContent}
---
Return your findings in clear bullet points.
";
            
            string promptClassFile = $@"
You are an expert .NET migration assistant.
Analyze the following **class file** '{Path.GetFileName(filePath)}' from an ASP.NET MVC project targeting .NET Framework {originalVersion}.
Identify legacy coding patterns, outdated C# language features, non-nullable reference handling, and dependency injection practices.
Recommend modernization strategies for .NET 8, including record types, `async` usage, proper DI registration, and updated namespace conventions.
Point out any breaking changes, obsolete APIs, and how to restructure the class for maintainability in .NET 8.
---
{fileContent}
---
Return your findings in clear bullet points.
";
            
            string promptCodeBehind = $@"
You are an expert .NET migration assistant.
Analyze the following **ASPX code-behind file** '{Path.GetFileName(filePath)}' originally written for .NET Framework {originalVersion}.
Highlight use of outdated `Page_Load` patterns, control events, server-side logic tightly coupled to UI, and ViewState reliance.
Provide detailed guidance for migrating the logic to Razor Pages, MVC controllers, or minimal APIs in .NET 8.
Explain how to refactor event-based patterns into clean, testable, modern ASP.NET Core code.
---
{fileContent}
---
Return your findings in clear bullet points.
";
            
            string promptMasterPage = $@"
You are an expert .NET migration assistant.
Evaluate the following **master page code file** '{Path.GetFileName(filePath)}' used in ASP.NET Web Forms or MVC Master Pages (.NET Framework {originalVersion}).
Identify use of legacy layout constructs, ViewState, code-behind logic, and page lifecycle events.
Recommend migration approaches to Razor `_Layout.cshtml`, partial views, or reusable components in .NET 8.
Describe how to handle dynamic content rendering, section definitions, and dependency injection cleanly.
---
{fileContent}
---
Return your findings in clear bullet points.
";

            var options = new ChatCompletionOptions()
            {
                MaxOutputTokenCount = 8192,
                Temperature = 0.2f
            };

            List<ChatMessage> messages = new List<ChatMessage>();

            switch (fileTypeEnum)
            {
                case FileType.ControllerFile:
                    messages = new List<ChatMessage>()
                    {
                        new SystemChatMessage("You are a helpful .NET migration expert."),
                        new UserChatMessage(promptController) 
                    };
                    break;
                case FileType.ModelFile:
                    messages = new List<ChatMessage>()
                    {
                        new SystemChatMessage("You are a helpful .NET migration expert."),
                        new UserChatMessage(promptModel)
                    };
                    break;
                case FileType.AspxPage:
                    messages = new List<ChatMessage>()
                    {
                        new SystemChatMessage("You are a helpful .NET migration expert."),
                        new UserChatMessage(promptAspx)
                    };
                    break;
                case FileType.WebOrAppConfig:
                    messages = new List<ChatMessage>()
                    {
                        new SystemChatMessage("You are a helpful .NET migration expert."),
                        new UserChatMessage(promptConfig)
                    };
                    break;
                case FileType.JavaScriptClientCode:
                    messages = new List<ChatMessage>()
                    {
                        new SystemChatMessage("You are a helpful .NET migration expert."),
                        new UserChatMessage(promptScript)
                    };
                    break;
                case FileType.CssStaticAsset:
                    messages = new List<ChatMessage>()
                    {
                        new SystemChatMessage("You are a helpful .NET migration expert."),
                        new UserChatMessage(promptAssets)
                    };
                    break;
                case FileType.PartialView:
                    messages = new List<ChatMessage>()
                    {
                        new SystemChatMessage("You are a helpful .NET migration expert."),
                        new UserChatMessage(promptpartialView)
                    };
                    break;
                case FileType.DataAccessFile:
                    messages = new List<ChatMessage>()
                    {
                        new SystemChatMessage("You are a helpful .NET migration expert."),
                        new UserChatMessage(promptDataAccess)
                    };
                    break;
                case FileType.ClassFile:
                    messages = new List<ChatMessage>()
                    {
                        new SystemChatMessage("You are a helpful .NET migration expert."),
                        new UserChatMessage(promptClassFile)
                    };
                    break;

                case FileType.CodeBehindFile:
                    messages = new List<ChatMessage>()
                    {
                        new SystemChatMessage("You are a helpful .NET migration expert."),
                        new UserChatMessage(promptCodeBehind)
                    };
                    break;

                case FileType.MasterPageFile:
                    messages = new List<ChatMessage>()
                    {
                        new SystemChatMessage("You are a helpful .NET migration expert."),
                        new UserChatMessage(promptMasterPage)
                    };
                    break;
                case FileType.GlobalAsaxFile:
                    messages = new List<ChatMessage>()
                    {
                        new SystemChatMessage("You are a helpful .NET migration expert."),
                        new UserChatMessage(promptGlobalAsax)
                    };
                    break;
                default:
                    throw new ArgumentException($"Unsupported file type: {fileTypeEnum}");
            }

            ChatClient chatClient = _client.GetChatClient(_deploymentName);

            var response = await chatClient.CompleteChatAsync(messages, options);
            return response.Value.Content[0].Text.Trim();
        }

        public async Task<string> AnalyzeFileAsync(string filePath, string fileType, string fileContent)
        {
            // You may want smarter prompt customization here!
            string prompt = $@"
You are an expert .NET migration assistant.
Analyze the following {fileType} file '{Path.GetFileName(filePath)}'.
Identify legacy patterns, migration risks, and recommendations to upgrade it to .NET 8 ({fileType}-specific issues, API changes, obsolete APIs, configuration/namespace requiring attention, and migration tips).
---
{fileContent}
---
Return your findings in clear bullet points.
";

            var options = new ChatCompletionOptions()
            {
                MaxOutputTokenCount = 8192,
                Temperature = 0.2f
            };

            List<ChatMessage> messages = new List<ChatMessage>()
            {
                new SystemChatMessage("You are a helpful .NET migration expert."),
                new UserChatMessage(prompt),
            };

            ChatClient chatClient = _client.GetChatClient(_deploymentName);

            var response = await chatClient.CompleteChatAsync(messages, options);
            return response.Value.Content[0].Text.Trim();
        }
    }
}
