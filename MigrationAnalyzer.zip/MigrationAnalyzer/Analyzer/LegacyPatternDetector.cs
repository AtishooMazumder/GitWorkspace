﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MigrationAnalyzer.Analyzer
{
    public static class LegacyPatternDetector
    {
        public static bool UsesSystemWeb(string fileContent)
        {
            return fileContent.Contains("System.Web");
        }
        // Add more pattern methods here
    }
}
