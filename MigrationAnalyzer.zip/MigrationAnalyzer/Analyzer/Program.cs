﻿//using Azure;
//using Azure.AI.OpenAI;
//using MigrationAnalyzer.Analyzer;
//using OpenAI;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace MigrationAnalyzer.Analyzer
//{
//    public class Program
//    {
//        public static void Main(string[] args)
//        {

//            Console.WriteLine("Enter path to legacy project:");
//            var projectPath = Console.ReadLine();

//            if (string.IsNullOrWhiteSpace(projectPath) || !Directory.Exists(projectPath))
//            {
//                Console.WriteLine("Invalid directory.");
//                return;
//            }

//            // Set your endpoint, key, and deployment name
//            var endpoint = new Uri("https://cmf-ai-foundry.cognitiveservices.azure.com/");
//            var apiKey = "8IHKWwsPG4sY44e4BgcBmS9Dyh2evwfJZkBjDbbxUeMuTvsxkcKpJQQJ99BFACYeBjFXJ3w3AAAAACOG5GOx";
//            var deploymentName = "gpt-4.1-2";
//            var openAiClient = new AzureOpenAIClient(endpoint, new AzureKeyCredential(apiKey));
//            var gptAnalyzer = new GptFileAnalyzer(openAiClient, deploymentName);

//            var scanner = new ProjectScanner(gptAnalyzer);
//            var projectInfo = await scanner.ScanProjectAsync(projectPath);

//            var markdown = ProjectReportGenerator.GenerateMarkdown(projectInfo);
//            var reportPath = Path.Combine(Directory.GetCurrentDirectory(), "DetailedMigrationReport.md");
//            await File.WriteAllTextAsync(reportPath, markdown);

//            Console.WriteLine($"Detailed migration report generated: {reportPath}");
//        }
//    }
//}

