﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MigrationAnalyzer.Models
{
    public class ProjectInfo
    {
        public string CsProjPath { get; set; }
        public List<string> Controllers { get; set; } = new();
        public List<string> Models { get; set; } = new();
        public List<AnalyzedFileInfo> Files { get; set; } = new();
        public string WebConfigContent { get; set; }
    }
}
