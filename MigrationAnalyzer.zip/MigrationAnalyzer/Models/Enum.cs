﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MigrationAnalyzer.Models
{
    public enum FileType
    {
        [Description("Unknown")]
        Unknown,

        [Description("Controller File")]
        ControllerFile,

        [Description("Model File")]
        ModelFile,

        [Description("ASPX Page (View)")]
        AspxPage,

        [Description("Partial View (.ascx, .cshtml)")]
        PartialView,

        [Description("Web.config/App.config")]
        WebOrAppConfig,

        [Description("JavaScript/Client Code")]
        JavaScriptClientCode,

        [Description("CSS/Static Assets")]
        CssStaticAsset,

        [Description("Data Access/File (e.g., Repository, DbContext)")]
        DataAccessFile,

        [Description("Class File")]
        ClassFile,

        [Description("ASPX Code-Behind File")]
        CodeBehindFile,

        [Description("Master Page Code File")]
        MasterPageFile,

        [Description("Global.asax or global.asax.cs or global.asax.designer.cs File")]
        GlobalAsaxFile
    }
}
