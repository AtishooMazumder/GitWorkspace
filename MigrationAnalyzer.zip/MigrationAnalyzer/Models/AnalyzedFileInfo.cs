﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MigrationAnalyzer.Models
{
    public class AnalyzedFileInfo
    {
        public string FilePath { get; set; }
        public string FileType { get; set; } // Controller, Model, View, Config, Other
        public string AnalysisResult { get; set; }
    }
}
